<?php
//session_start();
//session_destroy(); 


session_start();
session_destroy(); 
//header("Location:../index.php?ex=1");

 include("banner.php"); ?>

	<div class="page-content container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4">
				<div class="login-wrapper">
			        
                    
                    
                    <div class="box">
			            <div class="content-wrap">
			                <h6>Sign In</h6>
						
                          <form action="test.php" method="post">  
		                  <input class="form-control" type="text" placeholder="User ID" name="user_name">
			                <input class="form-control" type="password" placeholder="Password" name="password">
                            

<br/><br/>  
			                 <button type="submit" class="btn btn-primary">Login</button>
                           </form>                       
			            </div>
			        </div>
                   
                    

			       
                    
			    </div>
                
                
			</div>
            
		</div>
	</div>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
  </body>
</html>