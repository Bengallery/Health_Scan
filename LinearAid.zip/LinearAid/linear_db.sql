-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2020 at 01:43 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `linear_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `linear_scan`
--

CREATE TABLE IF NOT EXISTS `linear_scan` (
`id` int(10) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `other_names` varchar(255) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `phone_num` varchar(50) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `mat_bpd` varchar(100) NOT NULL,
  `mat_ga1` varchar(100) NOT NULL,
  `mat_edd1` varchar(100) NOT NULL,
  `mat_ac` varchar(100) NOT NULL,
  `mat_ga2` varchar(100) NOT NULL,
  `mat_edd2` varchar(100) NOT NULL,
  `mat_fl` varchar(100) NOT NULL,
  `mat_ga3` varchar(100) NOT NULL,
  `mat_edd3` varchar(100) NOT NULL,
  `mat_afa` varchar(100) NOT NULL,
  `mat_ga4` varchar(100) NOT NULL,
  `mat_fhr` varchar(100) NOT NULL,
  `impr1` varchar(100) NOT NULL,
  `impr2` varchar(100) NOT NULL,
  `impr_ga` varchar(100) NOT NULL,
  `impr_edd` varchar(100) NOT NULL,
  `impr_efw` varchar(100) NOT NULL,
  `impr_gender` varchar(100) NOT NULL,
  `impr_placenta` varchar(100) NOT NULL,
  `impr_amn_vol` varchar(100) NOT NULL,
  `impr_resc_date` varchar(100) NOT NULL,
  `comment` text NOT NULL,
  `scan_img` varchar(255) NOT NULL,
  `scan_date` varchar(50) NOT NULL,
  `scan_status` varchar(10) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `linear_scan`
--

INSERT INTO `linear_scan` (`id`, `surname`, `other_names`, `gender`, `dob`, `phone_num`, `contact`, `mat_bpd`, `mat_ga1`, `mat_edd1`, `mat_ac`, `mat_ga2`, `mat_edd2`, `mat_fl`, `mat_ga3`, `mat_edd3`, `mat_afa`, `mat_ga4`, `mat_fhr`, `impr1`, `impr2`, `impr_ga`, `impr_edd`, `impr_efw`, `impr_gender`, `impr_placenta`, `impr_amn_vol`, `impr_resc_date`, `comment`, `scan_img`, `scan_date`, `scan_status`) VALUES
(1, 'Daniel', 'kunle', 'Male', '2020-07-06', '08000899', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2020-07-06 15:53:44', ''),
(2, 'Blessing', 'benjamin', 'Male', '1986-08-12', '08037490533', '12 okofilling, Lagos', '1', '2', '3', '4', '5', '6', '7', '8', '8', '10', '11', '12', 'good impression', 'best impression', '13', '14', '15', 'XY', '16', 'Ok', '2020-07-27', 'This is the final comment', '', '2020-07-06 15:55:57', '');

-- --------------------------------------------------------

--
-- Table structure for table `linear_user`
--

CREATE TABLE IF NOT EXISTS `linear_user` (
`id` int(10) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `linear_user`
--

INSERT INTO `linear_user` (`id`, `user_name`, `password`, `type`) VALUES
(1, 'admin', 'admin12', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `linear_scan`
--
ALTER TABLE `linear_scan`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `linear_user`
--
ALTER TABLE `linear_user`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `linear_scan`
--
ALTER TABLE `linear_scan`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `linear_user`
--
ALTER TABLE `linear_user`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
