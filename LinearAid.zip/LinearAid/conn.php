<?php
define ('DB_USER', 'root');
define ('DB_PASSWORD', '');
define ('DB_HOST', 'localhost');
define ('DB_NAME', 'linear_db');

$conn = mysqli_connect (DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if(!$conn){
 die('Failure: ' . mysqli_error());
}

//mysqli_select_db(DB_NAME);

print "
<script language=\"JavaScript\" type=\"text/javascript\" 
src=\"../ui/script.js\"></script>
<link href=\"../ui/style.css\" rel=\"stylesheet\" 
type=\"text/css\" />
";

//Priviledge monitor
session_start();

//error_reporting(E_ERROR | E_PARSE);
?>