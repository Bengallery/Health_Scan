<?php
//create and issue query
include("conn.php");


	$user_name = mysqli_escape_string($conn, $_POST['user_name']);
	$password = mysqli_escape_string($conn, $_POST['password']);	


//Its a School	
		$sql = "SELECT * FROM linear_user WHERE user_name='$user_name' AND password = '$password'";
		$result = mysqli_query($conn, $sql) or die(mysqli_error());
		
		//get the number of rows in the result set; should be 1 if a match
		if (mysqli_num_rows($result) == 1) {
			//if authorized, get the values of f_name n l_name
			$info = mysqli_fetch_array($result);
				$f_name = $info['user_name'];
				$s_name = $info['password'];
			//use session instead of cookie AND DIRECT USER TO SUCCESS PAGE
			session_start();
			$_SESSION['id']=$id;	
			$_SESSION['u']=$f_name;	
			$_SESSION['p']=$s_name;	
				
				header("Location:login/home.php");
			} else {
			
						print "
						<br>
						<br>
						<br>
						<br>
						Sorry: either the User ID or Password, you provide is incorrect. 
						<p>
						<a href=\"index.php\">Click here to try again</a>
						";
						
			}

?>