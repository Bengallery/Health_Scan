<?php 
	include("banner1.php"); 

	if(isset($_REQUEST['post'])){
	 
        //include("picture_upload.php"); //Upload image
		$surname = mysqli_escape_string($conn, $_POST['surname']);
		$other_names = mysqli_escape_string($conn, $_POST['other_names']);
		$gender = mysqli_escape_string($conn, $_POST['gender']);
		$dob = mysqli_escape_string($conn, $_POST['dob']);
		$phone_num = mysqli_escape_string($conn, $_POST['phone_num']);
		$contact = mysqli_escape_string($conn, $_POST['contact']);
		$mat_bpd = mysqli_escape_string($conn, $_POST['mat_bpd']);
		$mat_ga1 = mysqli_escape_string($conn, $_POST['mat_ga1']);
		$mat_edd1 = mysqli_escape_string($conn, $_POST['mat_edd1']);
		$mat_ac = mysqli_escape_string($conn, $_POST['mat_ac']);
		$mat_ga2 = mysqli_escape_string($conn, $_POST['mat_ga2']);
		$mat_edd2 = mysqli_escape_string($conn, $_POST['mat_edd2']);
		$mat_fl = mysqli_escape_string($conn, $_POST['mat_fl']);
		$mat_ga3 = mysqli_escape_string($conn, $_POST['mat_ga3']);
		$mat_edd3 = mysqli_escape_string($conn, $_POST['mat_edd3']);
		$mat_afa = mysqli_escape_string($conn, $_POST['mat_afa']);
		$mat_ga4 = mysqli_escape_string($conn, $_POST['mat_ga4']);
		$mat_fhr = mysqli_escape_string($conn, $_POST['mat_fhr']);
		$impr1 = mysqli_escape_string($conn, $_POST['impr1']);
		$impr2 = mysqli_escape_string($conn, $_POST['impr2']);
		$impr_ga = mysqli_escape_string($conn, $_POST['impr_ga']);
		$impr_edd = mysqli_escape_string($conn, $_POST['impr_edd']);
		$impr_efw = mysqli_escape_string($conn, $_POST['impr_efw']);
		$impr_gender = mysqli_escape_string($conn, $_POST['impr_gender']);
		$impr_placenta = mysqli_escape_string($conn, $_POST['impr_placenta']);
		$impr_amn_vol = mysqli_escape_string($conn, $_POST['impr_amn_vol']);
		$impr_resc_date = mysqli_escape_string($conn, $_POST['impr_resc_date']);
		$comment = mysqli_escape_string($conn, $_POST['comment']);
		
		$add = "INSERT INTO linear_scan VALUES 
		(DEFAULT,'$surname','$other_names','$gender','$dob','$phone_num','$contact','$mat_bpd','$mat_ga1','$mat_edd1','$mat_ac','$mat_ga2','$mat_edd2','$mat_fl','$mat_ga3','$mat_edd3','$mat_afa','$mat_ga4','$mat_fhr','$impr1','$impr2','$impr_ga','$impr_edd','$impr_efw','$impr_gender','$impr_placenta','$impr_amn_vol','$impr_resc_date','$comment','',now(),'')";
		mysqli_query($conn, $add) or die(mysqli_error());
			
		$msg="<h4><font color=\"blue\">Record created</font></h4>";
	 
	}	
?>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
  	  <?php include("navigation1.php"); ?>
		  </div>
		  <div class="col-md-10">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
                    <b>SAVE OBSTETRIC SCAN REPORT</b>
                    </div>					
			  </div>
  				<div class="panel-body">
  					
 <form action="home.php" method="post" enctype="multipart/form-data" name="form1" id="form1" class="form-horizontal" >
<?php
if(isset($msg)){
	print $msg;
}

?>


PERSONAL
<div class="form-group">
	<label class="col-sm-2 control-label">Surname </label>
    <div class="col-sm-3">	
    	<input name="surname" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-2 control-label">Other names </label>
    <div class="col-sm-3">	
    	<input name="other_names" type="text" class="form-control" />      
	</div>
</div>			          

		         
                          
<div class="form-group">
	<label class="col-sm-2 control-label">Gender </label>
    <div class="col-sm-3">	
			<select name="gender" class="form-control">
  				<option>Male</option>
                <option>Female</option>
			</select>
    </div>
	
	<label class="col-sm-2 control-label">Date of Birth </label>
    <div class="col-sm-3">	
    	<input name="dob" type="date" class="form-control" />      
	</div>
</div>   



  
<div class="form-group">
	<label class="col-sm-2 control-label">Phone Number </label>
    <div class="col-sm-3">	
    	<input name="phone_num" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-2 control-label">Other contact details </label>
    <div class="col-sm-3">    			        
	<input name="contact" type="text" class="form-control" />
	</div>
</div>	         



<hr/>
MATURITY
<div class="form-group">
	<label class="col-sm-2 control-label">BPD</label>
    <div class="col-sm-2">	
    	<input name="mat_bpd" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-1 control-label">GA</label>
    <div class="col-sm-2">	
    	<input name="mat_ga1" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-1 control-label">EDD</label>
    <div class="col-sm-2">	
    	<input name="mat_edd1" type="text" class="form-control" />      
	</div>
	
</div>

<div class="form-group">
	<label class="col-sm-2 control-label">AC</label>
    <div class="col-sm-2">	
    	<input name="mat_ac" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-1 control-label">GA</label>
    <div class="col-sm-2">	
    	<input name="mat_ga2" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-1 control-label">EDD</label>
    <div class="col-sm-2">	
    	<input name="mat_edd2" type="text" class="form-control" />      
	</div>
	
</div>

<div class="form-group">
	<label class="col-sm-2 control-label">FL</label>
    <div class="col-sm-2">	
    	<input name="mat_fl" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-1 control-label">GA</label>
    <div class="col-sm-2">	
    	<input name="mat_ga3" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-1 control-label">EDD</label>
    <div class="col-sm-2">	
    	<input name="mat_edd3" type="text" class="form-control" />      
	</div>
	
</div>

<div class="form-group">
	<label class="col-sm-2 control-label">Average fetal age</label>
    <div class="col-sm-2">	
    	<input name="mat_afa" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-1 control-label">GA</label>
    <div class="col-sm-2">	
    	<input name="mat_ga4" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-1 control-label">FHR</label>
    <div class="col-sm-2">	
    	<input name="mat_fhr" type="text" class="form-control" />      
	</div>
	
</div>


<hr/>
IMPRESSION
<div class="form-group">
	<label class="col-sm-2 control-label">Impression 1 </label>
    <div class="col-sm-3">	
    	<input name="impr1" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-2 control-label">Impression 2 </label>
    <div class="col-sm-3">	
    	<input name="impr2" type="text" class="form-control" />      
	</div>
	
</div>


<div class="form-group">
	<label class="col-sm-2 control-label">GA</label>
    <div class="col-sm-2">	
    	<input name="impr_ga" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-1 control-label">EDD</label>
    <div class="col-sm-2">	
    	<input name="impr_edd" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-1 control-label">EFW</label>
    <div class="col-sm-2">	
    	<input name="impr_efw" type="text" class="form-control" />      
	</div>
	
</div>


<div class="form-group">
	<label class="col-sm-2 control-label">Gender</label>
    <div class="col-sm-3">	
    	<input name="impr_gender" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-2 control-label">Placenta </label>
    <div class="col-sm-3">	
    	<input name="impr_placenta" type="text" class="form-control" />      
	</div>
	
</div>


<div class="form-group">
	<label class="col-sm-2 control-label">Amniotic volumn</label>
    <div class="col-sm-3">	
    	<input name="impr_amn_vol" type="text" class="form-control" />      
	</div>
	
	<label class="col-sm-2 control-label">Rescan date</label>
    <div class="col-sm-3">	
    	<input name="impr_resc_date" type="date" class="form-control" />      
	</div>
	
</div>





<div class="form-group">
	<label class="col-sm-2 control-label">Comment </label>
    <div class="col-sm-8">    			        
	<textarea name="comment" cols="45" rows="5" class="form-control"></textarea>
	</div>
</div>


	
<div class="form-group">
	<div class="col-sm-offset-2 col-sm-10">
	<button type="submit" class="btn btn-primary">Submit</button>
    <button type="reset" class="btn btn-primary">Clear</button>
	</div>
</div>   
<input type="hidden" name="post" value="1">
        
</form>                   
  
                    
  				</div>
  			</div>
		  </div>
		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>