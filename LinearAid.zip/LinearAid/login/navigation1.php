<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    
<?php

	print '
	 <li><a href="home.php"><i class="glyphicon glyphicon-pencil"></i>Save Report</a></li>
	 <li><a href="view.php"><i class="glyphicon glyphicon-stats"></i>View Report</a></li>
	 <li><a href="home.php"><i class="glyphicon glyphicon-tasks"></i>Manage Report</a></li>	 
     <li><a href="../index.php"><i class="glyphicon glyphicon-eject"></i>Logout</a></li>
	';
	

?>

                   
                </ul>
             </div>