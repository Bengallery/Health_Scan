<?php
function randomizer($length) {
    $arr = array("1","2","3","4","5","6","7","8","9","0","Q","W","E","R","T","Y","U",
                    "I","O","P","A","S","D","F","G","H","J","K","L","Z","X",
                    "C","V","B","N","M");
    srand((float) microtime() * 1000000);
    for($i = $length; $i > 0; $i--) {
        $str .= $arr[rand(0, sizeof($arr))];        
    }
    return $str;
}
?>