<?php 
session_start();

if (!$_SESSION['p']){
	print "
	
	<p>
	Sorry your session has ended</font></b></p>
         <a href=\"../index.php\">Click here</a> and  Login again.";
	exit;
	}
include("../conn.php");	

/*
	if(isset($_SESSION['s_n'])){
		print $_SESSION['s_n'];
		print "<br />";
		print $_SESSION['address']; 
	}
	*/
	
?>
<!DOCTYPE html>
<html>
  <head>
    <title>LinearAid: Laboratory Services & Ultra Scan Center</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	
  
	
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="../css/styles.css" rel="stylesheet">

    <link href="../css/stats.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
	
	
  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-3">
	              <!-- Logo -->
	              <div class="logo">
	                 <font color="white"><h3>LinearAid</h3>
					 </font>
	              </div>
	           </div>
	           <div class="col-md-5">
			   <font color="white">Laboratory Services & Ultra Scan Center</font>
	           </div>
               
	           <div class="col-md-4">
					<font color="white">
	              Welcome: 
                   	 <?php 
					 //print $_SESSION['id'];
							if(isset($_SESSION['u'])){
								print "<b>".$_SESSION['u']."</b>";
							}
						?>
						</font>
	           </div>
	        </div>
	     </div>
	</div>