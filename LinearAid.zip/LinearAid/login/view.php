<?php 
include("banner1.php"); 

if($_REQUEST['search'] != ""){
	$search_word=mysql_escape_string($_REQUEST['search']);
	$msg="Search word: <b>".$search_word."</b>";
}
?>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
  	  <?php include("navigation1.php"); ?>
		  </div>
		  <div class="col-md-10">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
                    <b>SEE OBSTETRIC SCAN REPORT</b>
                    </div>					
			  </div>
  				<div class="panel-body">
  					
<form id="form1" name="form1" method="post" action="" class="form-horizontal">
<div class="form-group">
<label class="col-sm-2 control-label">Search </label>
    <div class="col-sm-6">    
         <input name="search" type="text" class="form-control" placeholder="Enter client name or phone to search" />
	</div>
     <div class="col-sm-2">
    
    <input name="acivate" type="hidden" id="acivate" value="go" />
    <button type="submit" class="btn btn-primary">Search</button>
    </div>
</div>
</form>

<?php
	if(isset($msg)){
		print "<font color=\"blue\">".$msg."</font>";
	}	
?>
				  
<?php
if($_REQUEST['search'] != ""){	

	$sql  = "SELECT * FROM linear_scan WHERE surname LIKE'%$search_word%'";
	$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));

}else{
	$rowsPerPage = 50;

	// by default we show first page
	$pageNum = 1;

	// if $_GET['page'] defined, use it as page number
	if(isset($_GET['page']))
	{
		$pageNum = $_GET['page'];
	}

	// counting the offset
	$offset = ($pageNum - 1) * $rowsPerPage;


	$sql = "SELECT * FROM linear_scan ";
	$pagingQuery = "ORDER BY surname ASC LIMIT $offset, $rowsPerPage";

	$result = mysqli_query($conn, $sql . $pagingQuery) or die(mysqli_error($conn));
}

	


// print the random numbers
if (mysqli_num_rows($result) <> 0) {
	print "<table class=\"table table-hover\">
	<thead>
		<td>Scan Date</td>
		<td>Surname</td>
		<td>Other names</td>
		<td>Gender</td>
		<td>Phone</td>
		<td></td>
	</thead>	
	";
	
	while($info = mysqli_fetch_array($result)){
			 
			 $id=$info['id'];
			 $scan_date=$info['scan_date'];
			 $surname=$info['surname'];
			 $other_names=$info['other_names'];	
			 $gender=$info['gender'];
			 $phone_num=$info['phone_num'];			 
			 
		print "
		
		<tr>
			<td>$scan_date</td>
			<td>$surname</td>
			<td>$other_names</td>
			<td>$gender</td>
			<td>$phone_num</td>
			<td><a href=\"view_detail.php?id=$id\">See Detail</a></td>
		<tr/>
		";
		}
	print "<table>";	
	
}else{
	print "No record yet!";	
}

if($_REQUEST['search'] == ""){
		// how many rows we have in database
		$result  = mysqli_query($conn,$sql) or die(mysqli_error($conn));
		$numrows = mysqli_num_rows($result);

		// how many pages we have when using paging?
		$maxPage = ceil($numrows/$rowsPerPage);

		$self = $_SERVER['PHP_SELF'];

		// creating 'previous' and 'next' link
		// plus 'first page' and 'last page' link

		// print 'previous' link only if we're not
		// on page one
		if ($pageNum > 1)
		{
			$page = $pageNum - 1;
			$prev = " <a href=\"$self?page=$page&id=$_GET[id]\">[Prev]</a> ";

			$first = " <a href=\"$self?page=1&id=$_GET[id]\">[First Page]</a> ";
		}
		else
		{
			$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
			$first = ' [First Page] '; // nor 'first page' link
		}

		// print 'next' link only if we're not
		// on the last page
		if ($pageNum < $maxPage)
		{
			$page = $pageNum + 1;
			$next = " <a href=\"$self?page=$page&id=$_GET[id]\">[Next]</a> ";

			$last = " <a href=\"$self?page=$maxPage&id =$_GET[id]\">[Last Page]</a> ";
		}
		else
		{
			$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
			$last = ' [Last Page] '; // nor 'last page' link
		}

		// print the page navigation link
		echo $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last;

		if ($maxPage == 0) {
		print "<p>no record found</p>";
		}

}
?>              
  
                    
  				</div>
  			</div>
		  </div>
		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>