<?php include("banner1.php"); 

// ================================== INSERTION STARTS HERE==================================
include("picture_upload.php");

// ====================================================================================================
//$reg_no = mysqli_escape_string($conn, $_POST['reg_no']);
$fname = mysqli_escape_string($conn, $_POST['fname']);
$other_name = mysqli_escape_string($conn, $_POST['other_name']);
$gender = mysqli_escape_string($conn, $_POST['gender']);
$dob = mysqli_escape_string($conn, $_POST['dob']);
$contact = mysqli_escape_string($conn, $_POST['contact']);
$phone = mysqli_escape_string($conn, $_POST['phone']);
$state = mysqli_escape_string($conn, $_POST['state']);
$country = mysqli_escape_string($conn, $_POST['country']);
$year_session = mysqli_escape_string($conn, $_POST['year_session']);
$class = mysqli_escape_string($conn, $_POST['class']);

$med_rec = mysqli_escape_string($conn, $_POST['med_rec']);
$comment = mysqli_escape_string($conn, $_POST['comment']);
$parent_guardian = mysqli_escape_string($conn, $_POST['parent_guardian']);
$parent_address = mysqli_escape_string($conn, $_POST['parent_address']);
$parent_phone = mysqli_escape_string($conn, $_POST['parent_phone']);
$email = mysqli_escape_string($conn, $_POST['email']);
$fn = mysqli_escape_string($conn, $fn);


//================================== GENERATES ID ==================================
	
$query  = "SELECT * FROM nems_student WHERE school_id = '$_SESSION[id]' AND class_subject ='$class' ORDER BY student_id DESC";
$result = mysqli_query($conn, $query) or die(mysqli_error());

$info = mysqli_fetch_array($result);
	$std = $info['student_id'];
	
$yr = substr($_SESSION['curr_session'],7);
$cl = $class;
$lst_num = $std+1;

$reg_no = $yr.$cl.$lst_num;
//======================================================================================	




//Initial payment 
$school_id = $_SESSION['id'];
$student_id = $reg_no;
$amount = mysqli_escape_string($conn, $_POST['amount']);
//$fee_id = 
$academic_session =  $_POST['year_session'];

$term = mysqli_escape_string($conn, $_POST['terms']);
$date = date('d-m-Y');
$payment_note = mysqli_escape_string($conn, $_POST['payment_note']);

if($_POST['initial_pay'] == "Yes"){ //execute if there is initial payment
	if(!is_numeric($amount)){
			print "<font color=\"red\">Sorry: <b>Initial Payment/School Fees</b> field must be NUMBER!</font>
			<br />
			<a href=\"javascript:history.back()\">Please, click here to return</a>
			";	
			exit();	
	}else{
			
				$add = "INSERT INTO nems_payment values 
				(DEFAULT,'$school_id','$student_id', now(), '$class', '$amount','$academic_session','$term','$payment_note')";
				mysqli_query($conn, $add) or die(mysqli_error());
					
				/*
				$add = "INSERT INTO nems_fees_record VALUES 
				('','$school_id', '$student_id','$amount','initial','$academic_session',
				'$term', now(),'$date', '$payment_note')";
								
				mysqli_query($conn, $add) or die(mysqli_error());
				*/
	
	}
}






					$add = "INSERT INTO nems_student values 
					(DEFAULT, '$fn',
					'$reg_no',
					'$_SESSION[id]',					
					'$fname',
					'$other_name',
					'$gender',
					'$dob',
					'$contact',
					'$phone',
					'$email',
					'$state',
					'$country',
					'$year_session',
					'NOT VERIFIED',					
					'$class',
					now(),'',
					'$med_rec','$comment','$parent_guardian','$parent_address','$parent_phone','',
					''
					)";
					
					mysqli_query($conn, $add) or die(mysqli_error());						
									
									
					
$msg = "Student registration was successfuly created.";
?>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
  	  <?php include("navigation1.php"); ?>
		  </div>
		  <div class="col-md-10">
          
          
           <div class="content-box-large">
			  <div class="panel-heading">
					<div class="panel-title">
                    SAVE STUDENT RECORD
              </div>					
			  </div>
  				<div class="panel-body">

        		<?php print $msg ?>
                <br/>
                <strong><a href="student.php"><span class="style7">CLICK HERE to Register Another student</span></a></strong>

             </div>
             
  			</div>
            
		  </div>
		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>