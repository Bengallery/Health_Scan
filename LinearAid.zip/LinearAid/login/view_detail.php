<?php 
	include("banner1.php"); 

	if(isset($_REQUEST['id'])){
		
		$sel_id=mysql_escape_string($_REQUEST['id']);
		
		$sql  = "SELECT * FROM linear_scan WHERE id='$sel_id'";
		$result = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		$info = mysqli_fetch_array($result);			 
			 $id=$info['id'];
			 $scan_date=$info['scan_date'];
			 $surname=$info['surname'];
			 $other_names=$info['other_names'];	
			 $gender=$info['gender'];
			 $dob=$info['dob'];
			 $phone_num=$info['phone_num'];
			 $contact=$info['contact'];	
			 $mat_bpd=$info['mat_bpd'];
			 $mat_ga1=$info['mat_ga1'];
			 $mat_edd1=$info['mat_edd1'];
			 $mat_ac=$info['mat_ac'];
			 $mat_ga2=$info['mat_ga2'];
			 $mat_edd2=$info['mat_edd2'];
			 $mat_fl=$info['mat_fl'];
			 $mat_ga3=$info['mat_ga3'];
			 $mat_edd3=$info['mat_edd3'];
			 $mat_afa=$info['mat_afa'];
			 $mat_ga4=$info['mat_ga4'];
			 $mat_fhr=$info['mat_fhr'];
			 $impr1=$info['impr1'];
			 $impr2=$info['impr2'];
			 $impr_ga=$info['impr_ga'];
			 $impr_edd=$info['impr_edd'];
			 $impr_efw=$info['impr_efw'];
			 $impr_gender=$info['impr_gender'];
			 $impr_placenta=$info['impr_placenta'];
			 $impr_amn_vol=$info['impr_amn_vol'];
			 $impr_resc_date=$info['impr_resc_date'];
			 $comment=$info['comment'];
			 $scan_img=$info['scan_img'];
			 $scan_date=$info['scan_date'];
			 $scan_status=$info['scan_status'];
			
	}else{
		exit();
	}
?>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
  	  <?php include("navigation1.php"); ?>
		  </div>
		  <div class="col-md-10">
           <div class="content-box-large">
		   <a href="view.php">Back</a>
			  <div class="panel-heading">				
					<div class="panel-title">
                    <b>SEE OBSTETRIC SCAN REPORT</b>
                    </div>					
			  </div>
  				<div class="panel-body">
  <?php
	print "<p align='right'>".$scan_date."</p>";
  ?>					

<table class="table table-hover">
	<tr>
		<td><b>Surname:</b> </td><td><?php print $surname; ?></td>	
		<td><b>Other Name:</b> </td><td><?php print $other_names; ?></td>
	</tr>
	<tr>
		<td><b>Gender:</b> </td><td><?php print $gender; ?></td>
		<td><b>Date of Birth:</b> </td><td><?php print $dob; ?></td>
	</tr>	
	<tr>
		<td><b>Phone Number:</b> </td><td><?php print $phone_num; ?></td>	
		<td><b>Other Contact detail:</b> </td><td><?php print $contact; ?></td>
	</tr>		
</table>

<?php print $comment; ?>

<h4>MATURITY</h4>
<!--<table width="70%" border="1">-->
<table class="table table-hover">
	<tr>
		<td width="25%" align="right"><b>BPD:</b> </td><td><?php print $mat_bpd; ?></td>
		<td width="25%" align="right"><b>GA:</b> </td><td><?php print $mat_ga1; ?></td>	
		<td width="25%" align="right"><b>EDD:</b> </td><td><?php print $mat_edd1; ?></td>	
		<td width="25%"></td> <td></td>		
	</tr>
	<tr>
		<td align="right"><b>AC:</b> </td><td><?php print $mat_ac; ?></td>
		<td align="right"><b>GA:</b> </td><td><?php print $mat_ga2; ?></td>	
		<td align="right"><b>EDD:</b> </td><td><?php print $mat_edd2; ?></td>	
		<td align="right"></td> <td></td>	
	</tr>
	<tr>
		<td align="right"><b>FL:</b> </td><td><?php print $mat_fl; ?></td>
		<td align="right"><b>GA:</b> </td><td><?php print $mat_fl; ?></td>	
		<td align="right"><b>EDD:</b> </td><td><?php print $mat_edd3; ?></td>		
		<td align="right"></td> <td></td>		
	</tr>
	
	<tr>
		<td align="right"><b>Average fetal age:</b> </td><td><?php print $mat_afa; ?></td>
		<td align="right"><b>GA:</b> </td><td><?php print $mat_ga4; ?></td>	
		<td align="right"><b>FHR:</b> </td><td><?php print $mat_fhr; ?></td>	
		<td align="right"></td> <td></td>	
	</tr>
	
</table>

<h4>IMPRESSION</h4>
<table class="table table-hover">
	<tr>
		<td align="right"><b>Impression 1:</b> </td><td><?php print $impr1; ?></td>
		<td align="right"><b>Impression 2:</b> </td><td><?php print $impr2; ?></td>	
		<td></td> <td></td>
	</tr>
	<tr>
		<td align="right"><b>GA:</b> </td><td><?php print $impr_ga; ?></td>
		<td align="right"><b>EDD:</b> </td><td><?php print $impr_edd; ?></td>
		<td align="right"><b>EFW:</b> </td><td><?php print $impr_efw; ?></td>		
	</tr>
	<tr>
		<td align="right"><b>Gender:</b> </td><td><?php print $impr_gender; ?></td>
		<td align="right"><b>Placenta:</b> </td><td><?php print $impr_placenta; ?></td>
		<td></td> <td></td>
	</tr>
	
	<tr>
		<td align="right"><b>Amniotic volumn:</b> </td><td><?php print $impr_amn_vol; ?></td>
		<td align="right"><b>Rescan date:</b> </td><td><?php print $impr_resc_date; ?></td>	
		<td></td> <td></td>
	</tr>
</table>

  
                    
  				</div>
  			</div>
		  </div>
		</div>
    </div>

       
    <?php include("../footer.php"); ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../vendors/morris/morris.css">


    <script src="../vendors/jquery.knob.js"></script>
    <script src="../vendors/raphael-min.js"></script>
    <script src="../vendors/morris/morris.min.js"></script>

    <script src="../vendors/flot/jquery.flot.js"></script>
    <script src="../vendors/flot/jquery.flot.categories.js"></script>
    <script src="../vendors/flot/jquery.flot.pie.js"></script>
    <script src="../vendors/flot/jquery.flot.time.js"></script>
    <script src="../vendors/flot/jquery.flot.stack.js"></script>
    <script src="../vendors/flot/jquery.flot.resize.js"></script>

    <script src="../js/custom.js"></script>
    <script src="../js/stats.js"></script>
  </body>
</html>