var strings = new Array();
strings['cancel'] = 'Mégsem';
strings['accept'] = 'OK';
strings['manual'] = 'Kézikönyv';
strings['latex'] = 'LaTeX';