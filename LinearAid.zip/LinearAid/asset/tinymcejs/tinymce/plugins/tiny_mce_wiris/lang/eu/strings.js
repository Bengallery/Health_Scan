var strings = new Array();
strings['cancel'] = 'Ezeztatu';
strings['accept'] = 'Onartu';
strings['manual'] = 'Gida';
strings['latex'] = 'LaTeX';