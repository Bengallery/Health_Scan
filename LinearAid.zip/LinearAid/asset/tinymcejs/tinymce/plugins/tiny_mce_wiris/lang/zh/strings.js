var strings = new Array();
strings['cancel'] = '取消';
strings['accept'] = '确定';
strings['manual'] = '手册';
strings['latex'] = 'LaTeX';