<footer>
         <div class="container">
         
            <div class="copy text-center">
Copyright (c) <?php print date('Y'); ?>. All Rights Resereved. <b>LinearAid (Laboratory Services & Ultra Scan Center)</b> | Developed  by BICL.com.ng <strong>
            </div>
            
         </div>
      </footer>